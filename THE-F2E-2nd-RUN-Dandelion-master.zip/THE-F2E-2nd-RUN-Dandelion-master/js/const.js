const cw = 800;
const ch = 450;
const scale = 0.6;
const monsterScale = 0.7;